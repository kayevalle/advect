

<!-- JavaScript Libraries -->
<script src="lib/jquery/jquery.min.js"></script>
<script src="lib/jquery/jquery-migrate.min.js"></script>
<script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="lib/wow/wow.min.js"></script>
<script src="lib/easing/easing.min.js"></script>
<script src="lib/owlcarousel/owl.carousel.min.js"></script>
<script src="lib/superfish/superfish.min.js"></script>
<script src="lib/sticky/sticky.js"></script>

<!-- Main Javascript File -->
<script src="js/main.js"></script>
<!-- <script src="../js/custom.js"></script> -->