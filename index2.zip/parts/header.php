
<header id="header">
  <div class="container">

    <div id="logo" class="pull-left" style="float: left;">
      <a href="index.php" class="scrollto"><img src="img/logo/logo.png"></a>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="#body"><img src="img/logo.png" alt="" title="" /></a>-->
    </div>

    <nav id="nav-menu-container">
      <ul class="nav-menu">
        <li><a class="home" href="index.php" id="home-link">Home</a></li>
        <li><a class="about-us" href="about-us.php">About Us</a></li>
        <li><a class="services" href="services.php">Services</a></li>
        <!-- <li><a class="partners" href="partners.php">Brand Partners</a></li> -->
        <li><a class="careers" href="careers.php">Careers</a></li>
        <li><a class="contact" href="contact-us.php">Contact</a></li>
      </ul>
    </nav><!-- #nav-menu-container -->
  </div>
</header>