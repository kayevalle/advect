
<footer>
    <div class="footer-container">
      <div class="row">
        <div class="logo col-lg-2 col-sm-12 offset-lg-1">
          <a href="index.php"><img src="img/logo/advect-white.png"></a>
        </div>
        <nav class="col-lg-4 col-sm-12">
          <ul class="link-primary" >
            <li ><a href="about-us.php">Our Company</a></li>
            <li><a href="careers.php">Careers</a></li>
          </ul>
          <ul class="link-seconday" >
            <li><a href="services.php">Services</a></li>
            <li><a href="contact-us.php">Contact Us</a></li>
          </ul>
        </nav>
        <div class="col-lg-2 col-sm-12 contact-details" >
          <address>
            <!-- Contact us on:<br><br> -->
            Tel: 940 - 1956 <br>
            advect.csgt@gmail.com
          </address>
        </div>
        <div class="col-lg-2 col-sm-12 social-link">
          <!-- <address>Like us on facebook</address> -->
          <a href=""><i class="fab fa-facebook"></i> advectmarketingcorp</a>
        </div>
        <p class="col-sm-12 copyright">&copy; 2017 Advect Marketing Corporation. All rights reserved.</p>
      </div>
    </div>
</footer>