

$(document).ready(function( ) {
		
	$('a[href=#contact]').click(function(){
		// var pageTarget = '/advectm/pages/home.php'
		$('#home-link').click();
		// window.location('/advectm/pages/home.php');
		// alert("succes");
	});

});